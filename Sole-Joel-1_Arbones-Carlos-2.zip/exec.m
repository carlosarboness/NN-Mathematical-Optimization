[X,y] = uo_nn_dataset(1234, 10, [4], 0.5); 
uo_nn_Xyplot(X, y, []); 